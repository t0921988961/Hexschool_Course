
var list = document.querySelector('.list');

//確認點擊的農夫是誰
function checkList(e){
  var num = e.target.dataset.num;
  var dog = e.target.dataset.dog;
  console.log('農夫標號是'+num);
  console.log('有'+dog+'隻狗');
}
list.addEventListener('click',checkList,false);