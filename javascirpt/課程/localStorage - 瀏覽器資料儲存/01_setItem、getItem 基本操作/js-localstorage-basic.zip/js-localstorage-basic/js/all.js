
var str = 'tom';

localStorage.setItem("myName", str);


console.log(localStorage.getItem('myName'));